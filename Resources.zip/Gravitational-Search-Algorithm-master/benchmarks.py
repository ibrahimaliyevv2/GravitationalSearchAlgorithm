# -*- coding: utf-8 -*-
"""
Python code of Gravitational Search Algorithm (GSA)
Reference: Rashedi, Esmat, Hossein Nezamabadi-Pour, and Saeid Saryazdi. "GSA: a gravitational search algorithm." 
           Information sciences 179.13 (2009): 2232-2248.	

Coded by: Mukesh Saraswat (saraswatmukesh@gmail.com), Himanshu Mittal (emailid: himanshu.mittal224@gmail.com) and Raju Pal (emailid: raju3131.pal@gmail.com)
The code template used is similar given at link: https://github.com/7ossam81/EvoloPy and matlab version of GSA at mathworks.

 -- Purpose: Defining the benchmark function code 
              and its parameters: function Name, lowerbound, upperbound, dimensions

Code compatible:
 -- Python: 2.* or 3.*
"""

import numpy as np
import math

    
def F1(x):
#   """ Rastrigin Function """   # [-5.12 , 5.12]
 # s= np.sum(x**2 - 10 * np.cos(2 * np.pi* x)) 

#   """ Ackley Function """    # [-5 , 5]
  #s = -20*np.exp(-0.2*np.sqrt(len(x)*np.sum(x**2)))-np.exp(len(x)*np.sum(np.cos(2*np.pi*x)))+20+np.e

#   """ Schewel Function """    # [-500 , 500]
#  s = 418.9829*2 - np.sum(-x*np.sin(np.sqrt(np.absolute(x))))

#   """ Rosenbrock Function """    # [-100 , 100]
  s = np.sum(100*(x[1:]-(x[:-1]**2))**2+(x[:-1]-1)**2)
  return s


  

def getFunctionDetails(a):
  # [name, lb, ub, dim]
  param = {  0: ["F1",-100,100,30],
            }
  return param.get(a, "nothing")




